﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 387,
              y: 251,
              src: 'Wid-L.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 321,
              y: 284,
              src: 'Wid-D.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 270,
              y: 75,
              src: 'Wid-B.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 152,
              y: 75,
              src: 'Wid-A.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 267,
              month_startY: 118,
              month_sc_array: ["Month00.png","Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png"],
              month_tc_array: ["Month00.png","Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png"],
              month_en_array: ["Month00.png","Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 116,
              y: 118,
              week_en: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              week_tc: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              week_sc: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 208,
              day_startY: 118,
              day_sc_array: ["grey00.png","grey01.png","grey02.png","grey03.png","grey04.png","grey05.png","grey06.png","grey07.png","grey08.png","grey09.png"],
              day_tc_array: ["grey00.png","grey01.png","grey02.png","grey03.png","grey04.png","grey05.png","grey06.png","grey07.png","grey08.png","grey09.png"],
              day_en_array: ["grey00.png","grey01.png","grey02.png","grey03.png","grey04.png","grey05.png","grey06.png","grey07.png","grey08.png","grey09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 274,
              font_array: ["grey00.png","grey01.png","grey02.png","grey03.png","grey04.png","grey05.png","grey06.png","grey07.png","grey08.png","grey09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'CF.png',
              unit_tc: 'CF.png',
              unit_en: 'CF.png',
              negative_image: 'Neg00.png',
              invalid_image: 'Error00.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 61,
              y: 198,
              image_array: ["wather001.png","wather002.png","wather003.png","wather004.png","wather005.png","wather006.png","wather007.png","wather008.png","wather009.png","wather010.png","wather011.png","wather012.png","wather013.png","wather014.png","wather015.png","wather016.png","wather017.png","wather018.png","wather019.png","wather020.png","wather021.png","wather022.png","wather023.png","wather024.png","wather025.png","wather026.png","wather027.png","wather028.png","wather029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 325,
              font_array: ["grey00.png","grey01.png","grey02.png","grey03.png","grey04.png","grey05.png","grey06.png","grey07.png","grey08.png","grey09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'point.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 325,
              font_array: ["grey00.png","grey01.png","grey02.png","grey03.png","grey04.png","grey05.png","grey06.png","grey07.png","grey08.png","grey09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 165,
              font_array: ["grey00.png","grey01.png","grey02.png","grey03.png","grey04.png","grey05.png","grey06.png","grey07.png","grey08.png","grey09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 165,
              font_array: ["grey00.png","grey01.png","grey02.png","grey03.png","grey04.png","grey05.png","grey06.png","grey07.png","grey08.png","grey09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 39,
              font_array: ["grey00.png","grey01.png","grey02.png","grey03.png","grey04.png","grey05.png","grey06.png","grey07.png","grey08.png","grey09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 326,
              am_y: 215,
              am_sc_path: 'Mode-A.png',
              am_en_path: 'Mode-A.png',
              pm_x: 326,
              pm_y: 215,
              pm_sc_path: 'Mode-P.png',
              pm_en_path: 'Mode-P.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 153,
              hour_startY: 151,
              hour_array: ["hour00.png","hour01.png","hour02.png","hour03.png","hour04.png","hour05.png","hour06.png","hour07.png","hour08.png","hour09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 153,
              minute_startY: 247,
              minute_array: ["minute00.png","minute01.png","minute02.png","minute03.png","minute04.png","minute05.png","minute06.png","minute07.png","minute08.png","minute09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 311,
              second_startY: 249,
              second_array: ["second00.png","second01.png","second02.png","second03.png","second04.png","second05.png","second06.png","second07.png","second08.png","second09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand-H.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 16,
              hour_posY: 140,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand-M.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 13,
              minute_posY: 179,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand-S.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 6,
              second_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AODbackground.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 267,
              month_startY: 118,
              month_sc_array: ["AODMonth00.png","AODMonth01.png","AODMonth02.png","AODMonth03.png","AODMonth04.png","AODMonth05.png","AODMonth06.png","AODMonth07.png","AODMonth08.png","AODMonth09.png","AODMonth10.png","AODMonth11.png"],
              month_tc_array: ["AODMonth00.png","AODMonth01.png","AODMonth02.png","AODMonth03.png","AODMonth04.png","AODMonth05.png","AODMonth06.png","AODMonth07.png","AODMonth08.png","AODMonth09.png","AODMonth10.png","AODMonth11.png"],
              month_en_array: ["AODMonth00.png","AODMonth01.png","AODMonth02.png","AODMonth03.png","AODMonth04.png","AODMonth05.png","AODMonth06.png","AODMonth07.png","AODMonth08.png","AODMonth09.png","AODMonth10.png","AODMonth11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 116,
              y: 118,
              week_en: ["AODWeek01.png","AODWeek02.png","AODWeek03.png","AODWeek04.png","AODWeek05.png","AODWeek06.png","AODWeek07.png"],
              week_tc: ["AODWeek01.png","AODWeek02.png","AODWeek03.png","AODWeek04.png","AODWeek05.png","AODWeek06.png","AODWeek07.png"],
              week_sc: ["AODWeek01.png","AODWeek02.png","AODWeek03.png","AODWeek04.png","AODWeek05.png","AODWeek06.png","AODWeek07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 208,
              day_startY: 118,
              day_sc_array: ["AOD00.png","AOD01.png","AOD02.png","AOD03.png","AOD04.png","AOD05.png","AOD06.png","AOD07.png","AOD08.png","AOD09.png"],
              day_tc_array: ["AOD00.png","AOD01.png","AOD02.png","AOD03.png","AOD04.png","AOD05.png","AOD06.png","AOD07.png","AOD08.png","AOD09.png"],
              day_en_array: ["AOD00.png","AOD01.png","AOD02.png","AOD03.png","AOD04.png","AOD05.png","AOD06.png","AOD07.png","AOD08.png","AOD09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 276,
              font_array: ["AOD00.png","AOD01.png","AOD02.png","AOD03.png","AOD04.png","AOD05.png","AOD06.png","AOD07.png","AOD08.png","AOD09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AODpercent.png',
              unit_tc: 'AODpercent.png',
              unit_en: 'AODpercent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 276,
              font_array: ["AOD00.png","AOD01.png","AOD02.png","AOD03.png","AOD04.png","AOD05.png","AOD06.png","AOD07.png","AOD08.png","AOD09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 326,
              am_y: 215,
              am_sc_path: 'AOD-Mode-A.png',
              am_en_path: 'AOD-Mode-A.png',
              pm_x: 326,
              pm_y: 215,
              pm_sc_path: 'AOD-Mode-P.png',
              pm_en_path: 'AOD-Mode-P.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'AOD-Hand-H.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 16,
              hour_posY: 140,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'AOD-Hand-M.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 13,
              minute_posY: 179,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 314,
              w: 100,
              h: 100,
              src: 'Shortcut.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 40,
              w: 100,
              h: 100,
              src: 'Shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 314,
              y: 40,
              w: 100,
              h: 100,
              src: 'Shortcut.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 314,
              y: 314,
              w: 100,
              h: 100,
              src: 'Shortcut.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}