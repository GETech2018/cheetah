try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        let normal$_$component_1$_$component = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    bg_config: [
                        {
                            'id': 1,
                            'path': '6.png',
                            'preview': '7.png'
                        },
                        {
                            'id': 2,
                            'path': '8.png',
                            'preview': '9.png'
                        },
                        {
                            'id': 3,
                            'path': '10.png',
                            'preview': '11.png'
                        },
                        {
                            'id': 4,
                            'path': '12.png',
                            'preview': '13.png'
                        },
                        {
                            'id': 5,
                            'path': '14.png',
                            'preview': '15.png'
                        },
                        {
                            'id': 6,
                            'path': '16.png',
                            'preview': '17.png'
                        },
                        {
                            'id': 7,
                            'path': '18.png',
                            'preview': '19.png'
                        }
                    ],
                    count: 7,
                    default_id: 1,
                    fg: '5.png',
                    tips_x: 161,
                    tips_y: 25,
                    tips_bg: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: '293.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 18,
                    year_startY: 139,
                    year_sc_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    year_tc_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    year_en_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    year_align: hmUI.align.LEFT,
                    year_zero: 1,
                    year_space: 4,
                    year_is_character: false,
                    month_startX: 96,
                    month_startY: 131,
                    month_sc_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    month_tc_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    month_en_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 5,
                    month_is_character: false,
                    day_startX: 149,
                    day_startY: 122,
                    day_sc_array: [
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png'
                    ],
                    day_tc_array: [
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png'
                    ],
                    day_en_array: [
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 5,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 35,
                    y: 101,
                    week_en: [
                        '50.png',
                        '51.png',
                        '52.png',
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png'
                    ],
                    week_tc: [
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png',
                        '63.png'
                    ],
                    week_sc: [
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 37,
                    y: 332,
                    image_array: [
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png'
                    ],
                    image_length: 30,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 198,
                    y: 292,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 105,
                    y: 388,
                    type: hmUI.data_type.PAI_WEEKLY,
                    font_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 323,
                    y: 209,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 5,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '123.png',
                    unit_tc: '123.png',
                    unit_en: '123.png',
                    negative_image: '122.png',
                    invalid_image: '121.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 350,
                    y: 176,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '136.png',
                    unit_tc: '136.png',
                    unit_en: '136.png',
                    negative_image: '135.png',
                    invalid_image: '134.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 350,
                    y: 258,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '136.png',
                    unit_tc: '136.png',
                    unit_en: '136.png',
                    negative_image: '135.png',
                    invalid_image: '134.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 46,
                    y: 292,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '141.png',
                    unit_tc: '141.png',
                    unit_en: '141.png',
                    imperial_unit_sc: '141.png',
                    imperial_unit_tc: '141.png',
                    imperial_unit_en: '141.png',
                    dot_image: '140.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 190,
                    y: 361,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 5,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '121.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 416,
                    y: 209,
                    image_array: [
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png',
                        '149.png',
                        '150.png',
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png',
                        '161.png',
                        '162.png',
                        '163.png',
                        '164.png',
                        '165.png',
                        '166.png',
                        '167.png',
                        '168.png',
                        '169.png',
                        '170.png',
                        '171.png',
                        '172.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 248,
                    y: 97,
                    type: hmUI.data_type.SUN_RISE,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '141.png',
                    invalid_image: '134.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 248,
                    y: 135,
                    type: hmUI.data_type.SUN_SET,
                    font_array: [
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 2,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '141.png',
                    invalid_image: '175.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 78,
                    y: 45,
                    image_array: [
                        '177.png',
                        '178.png',
                        '179.png',
                        '180.png',
                        '181.png',
                        '182.png',
                        '183.png',
                        '184.png',
                        '185.png',
                        '186.png',
                        '187.png',
                        '188.png',
                        '189.png',
                        '190.png',
                        '191.png',
                        '192.png',
                        '193.png',
                        '194.png',
                        '195.png',
                        '196.png',
                        '197.png',
                        '198.png',
                        '199.png',
                        '200.png',
                        '201.png',
                        '202.png',
                        '203.png',
                        '204.png',
                        '205.png',
                        '206.png'
                    ],
                    image_length: 30,
                    type: hmUI.data_type.MOON,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 298,
                    y: 388,
                    type: hmUI.data_type.UVI,
                    font_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '175.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 326,
                    y: 290,
                    type: hmUI.data_type.HUMIDITY,
                    font_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '209.png',
                    unit_tc: '209.png',
                    unit_en: '209.png',
                    invalid_image: '175.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 326,
                    y: 135,
                    type: hmUI.data_type.ALTIMETER,
                    font_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '175.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 360,
                    y: 352,
                    image_array: [
                        '211.png',
                        '212.png',
                        '213.png',
                        '214.png',
                        '215.png',
                        '216.png',
                        '217.png',
                        '218.png'
                    ],
                    image_length: 8,
                    type: hmUI.data_type.WIND_DIRECTION,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 316,
                    y: 355,
                    type: hmUI.data_type.WIND,
                    font_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '175.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 252,
                    y: 24,
                    src: '224.png',
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 164,
                    y: 24,
                    src: '225.png',
                    type: hmUI.system_status.LOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 120,
                    y: 32,
                    src: '226.png',
                    type: hmUI.system_status.CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 295,
                    y: 32,
                    image_array: [
                        '227.png',
                        '228.png',
                        '229.png',
                        '230.png',
                        '231.png',
                        '232.png',
                        '233.png',
                        '234.png',
                        '235.png',
                        '236.png',
                        '237.png',
                        '238.png',
                        '239.png',
                        '240.png',
                        '241.png',
                        '242.png',
                        '243.png',
                        '244.png',
                        '245.png',
                        '246.png'
                    ],
                    image_length: 20,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 324,
                    y: 82,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '247.png',
                    unit_tc: '247.png',
                    unit_en: '247.png',
                    padding: false,
                    isCharacter: false
                });
					hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
						x: 179,
						y: 414,
						w: 96,
						h: 32,
						line_color: 0xff3333,
						line_width: 1,
						type: hmUI.data_type.HEART,
						show_level: hmUI.show_level.ONLY_NORMAL,
					});
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 2,
                    x: 23,
                    y: 348,
                    w: 150,
                    h: 40,
                    select_image: '248.png',
                    un_select_image: '249.png',
                    default_type: hmUI.edit_type.SPO2,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.SPO2,
                            'preview': '251.png'
                        },
                        {
                            'type': hmUI.edit_type.TRAINING_LOAD,
                            'preview': '252.png'
                        },
                        {
                            'type': hmUI.edit_type.VO2MAX,
                            'preview': '253.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '254.png'
                        },
                        {
                            'type': hmUI.edit_type.STRESS,
                            'preview': '255.png'
                        }
                    ],
                    count: 5,
                    select_list: {
                        title_font_size: 34,
                        title_align_h: hmUI.align.CENTER_H,
                        list_item_vspace: 8,
                        list_tips_text_font_size: 32,
                        list_tips_text_align_h: hmUI.align.LEFT
                    },
                    tips_BG: '4.png',
                    tips_x: 15,
                    tips_y: -60,
                    tips_width: 132,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 85,
                        y: 355,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '30.png',
                            '31.png',
                            '32.png',
                            '33.png',
                            '34.png',
                            '35.png',
                            '36.png',
                            '37.png',
                            '38.png',
                            '39.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 4,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '175.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 57,
                        y: 354,
                        w: 20,
                        h: 29,
                        src: '257.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 35,
                        y: 346,
                        w: 137,
                        h: 40,
                        type: hmUI.data_type.CAL,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 85,
                        y: 355,
                        type: hmUI.data_type.STRESS,
                        font_array: [
                            '30.png',
                            '31.png',
                            '32.png',
                            '33.png',
                            '34.png',
                            '35.png',
                            '36.png',
                            '37.png',
                            '38.png',
                            '39.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 4,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '175.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 55,
                        y: 351,
                        w: 25,
                        h: 36,
                        src: '259.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 35,
                        y: 346,
                        w: 137,
                        h: 40,
                        type: hmUI.data_type.STRESS,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 85,
                        y: 355,
                        type: hmUI.data_type.SPO2,
                        font_array: [
                            '30.png',
                            '31.png',
                            '32.png',
                            '33.png',
                            '34.png',
                            '35.png',
                            '36.png',
                            '37.png',
                            '38.png',
                            '39.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 4,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '175.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 56,
                        y: 355,
                        w: 25,
                        h: 29,
                        src: '261.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 35,
                        y: 346,
                        w: 137,
                        h: 40,
                        type: hmUI.data_type.SPO2,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 85,
                        y: 355,
                        type: hmUI.data_type.TRAINING_LOAD,
                        font_array: [
                            '30.png',
                            '31.png',
                            '32.png',
                            '33.png',
                            '34.png',
                            '35.png',
                            '36.png',
                            '37.png',
                            '38.png',
                            '39.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 4,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '175.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 56,
                        y: 354,
                        w: 25,
                        h: 29,
                        src: '263.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 35,
                        y: 346,
                        w: 137,
                        h: 40,
                        type: hmUI.data_type.TRAINING_LOAD,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.VO2MAX:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 85,
                        y: 355,
                        type: hmUI.data_type.VO2MAX,
                        font_array: [
                            '30.png',
                            '31.png',
                            '32.png',
                            '33.png',
                            '34.png',
                            '35.png',
                            '36.png',
                            '37.png',
                            '38.png',
                            '39.png'
                        ],
                        align_h: hmUI.align.LEFT,
                        h_space: 4,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '175.png',
                        padding: false,
                        isCharacter: false
                    });
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 55,
                        y: 350,
                        w: 30,
                        h: 37,
                        src: '264.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x: 35,
                        y: 346,
                        w: 137,
                        h: 40,
                        type: hmUI.data_type.VO2MAX,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                normal$_$component_1$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 3,
                    x: 16,
                    y: 182,
                    w: 286,
                    h: 90,
                    select_image: '266.png',
                    un_select_image: '267.png',
                    default_type: hmUI.edit_type.ALTIMETER,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.ALTIMETER,
                            'preview': '268.png'
                        },
                        {
                            'type': hmUI.edit_type.WIND,
                            'preview': '269.png'
                        },
                        {
                            'type': hmUI.edit_type.UVI,
                            'preview': '270.png'
                        },
                        {
                            'type': hmUI.edit_type.SUN,
                            'preview': '271.png'
                        },
                        {
                            'type': hmUI.edit_type.HUMIDITY,
                            'preview': '272.png'
                        },
                        {
                            'type': hmUI.edit_type.TEMPERATURE,
                            'preview': '273.png'
                        },
                        {
                            'type': hmUI.edit_type.AQI,
                            'preview': '274.png'
                        }
                    ],
                    count: 7,
                    tips_x: -16,
                    tips_y: -182,
                    tips_width: 0,
                    tips_margin: 0
                });
                editType = normal$_$component_1$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    break;
                case hmUI.edit_type.BATTERY:
                    break;
                case hmUI.edit_type.HEART:
                    break;
                case hmUI.edit_type.CAL:
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 20,
                        y: 186,
                        src: '275.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.HUMIDITY:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 20,
                        y: 186,
                        src: '276.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.ALTIMETER:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 20,
                        y: 186,
                        src: '277.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 20,
                        y: 186,
                        src: '278.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 20,
                        y: 186,
                        src: '279.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.DATE:
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 20,
                        y: 186,
                        src: '280.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.SUN:
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: 20,
                        y: 186,
                        src: '281.png',
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                }
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_centerX: 275,
                    second_centerY: 245,
                    second_posX: 22,
                    second_posY: 23,
                    second_path: '282.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 19,
                    hour_startY: 185,
                    hour_array: [
                        '283.png',
                        '284.png',
                        '285.png',
                        '286.png',
                        '287.png',
                        '288.png',
                        '289.png',
                        '290.png',
                        '291.png',
                        '292.png'
                    ],
                    hour_space: 7,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 137,
                    minute_startY: 185,
                    minute_array: [
                        '283.png',
                        '284.png',
                        '285.png',
                        '286.png',
                        '287.png',
                        '288.png',
                        '289.png',
                        '290.png',
                        '291.png',
                        '292.png'
                    ],
                    minute_space: 7,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 258,
                    second_startY: 185,
                    second_array: [
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png'
                    ],
                    second_space: 4,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 120,
                    hour_startY: 186,
                    hour_array: [
                        '294.png',
                        '295.png',
                        '296.png',
                        '297.png',
                        '298.png',
                        '299.png',
                        '300.png',
                        '301.png',
                        '302.png',
                        '303.png'
                    ],
                    hour_space: 8,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 238,
                    minute_startY: 186,
                    minute_array: [
                        '294.png',
                        '295.png',
                        '296.png',
                        '297.png',
                        '298.png',
                        '299.png',
                        '300.png',
                        '301.png',
                        '302.png',
                        '303.png'
                    ],
                    minute_space: 8,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 115,
                    y: 0,
                    w: 50,
                    h: 90,
                    type: hmUI.data_type.ALARM_CLOCK,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 154,
                    y: 287,
                    w: 162,
                    h: 56,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 63,
                    y: 386,
                    w: 109,
                    h: 63,
                    type: hmUI.data_type.PAI_WEEKLY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 318,
                    y: 168,
                    w: 134,
                    h: 118,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 9,
                    y: 287,
                    w: 144,
                    h: 56,
                    type: hmUI.data_type.DISTANCE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 174,
                    y: 346,
                    w: 105,
                    h: 105,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 208,
                    y: 86,
                    w: 107,
                    h: 79,
                    type: hmUI.data_type.SUN_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 282,
                    y: 384,
                    w: 108,
                    h: 64,
                    type: hmUI.data_type.UVI,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 319,
                    y: 288,
                    w: 122,
                    h: 36,
                    type: hmUI.data_type.HUMIDITY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 320,
                    y: 125,
                    w: 124,
                    h: 42,
                    type: hmUI.data_type.ALTIMETER,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 282,
                    y: 345,
                    w: 134,
                    h: 38,
                    type: hmUI.data_type.WIND,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}