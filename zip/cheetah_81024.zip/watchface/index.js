﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_stand_image_progress_img_level = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Fond05.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 200,
              y: 9,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 151,
              y: 39,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 321,
              y: 304,
              image_array: ["Batt01.png","Batt02.png","Batt03.png","Batt04.png","Batt05.png","Batt06.png","Batt07.png","Batt08.png","Batt09.png","Batt10.png","Batt11.png","Batt12.png","Batt13.png","Batt14.png","Batt15.png","Batt16.png"],
              image_length: 16,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 246,
              y: 304,
              image_array: ["Debout01.png","Debout02.png","Debout03.png","Debout04.png","Debout05.png","Debout06.png","Debout07.png","Debout08.png","Debout09.png","Debout10.png","Debout11.png","Debout12.png","Debout13.png","Debout14.png","Debout15.png","Debout16.png"],
              image_length: 16,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 170,
              y: 304,
              image_array: ["Pas01.png","Pas02.png","Pas03.png","Pas04.png","Pas05.png","Pas06.png","Pas07.png","Pas08.png","Pas09.png","Pas10.png","Pas11.png","Pas12.png","Pas13.png","Pas14.png","Pas15.png","Pas16.png"],
              image_length: 16,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 165,
              month_startY: 120,
              month_sc_array: ["Mois01.png","Mois02.png","Mois03.png","Mois04.png","Mois05.png","Mois06.png","Mois07.png","Mois08.png","Mois09.png","Mois10.png","Mois11.png","Mois12.png"],
              month_tc_array: ["Mois01.png","Mois02.png","Mois03.png","Mois04.png","Mois05.png","Mois06.png","Mois07.png","Mois08.png","Mois09.png","Mois10.png","Mois11.png","Mois12.png"],
              month_en_array: ["Mois01.png","Mois02.png","Mois03.png","Mois04.png","Mois05.png","Mois06.png","Mois07.png","Mois08.png","Mois09.png","Mois10.png","Mois11.png","Mois12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 266,
              day_startY: 85,
              day_sc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_tc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_en_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 165,
              y: 86,
              week_en: ["Jour1.png","Jour2.png","Jour3.png","Jour4.png","Jour5.png","Jour6.png","Jour7.png"],
              week_tc: ["Jour1.png","Jour2.png","Jour3.png","Jour4.png","Jour5.png","Jour6.png","Jour7.png"],
              week_sc: ["Jour1.png","Jour2.png","Jour3.png","Jour4.png","Jour5.png","Jour6.png","Jour7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 304,
              src: 'Mask2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 57,
              y: 75,
              image_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 73,
              y: 312,
              image_array: ["lune01.png","lune02.png","lune03.png","lune04.png","lune05.png","lune06.png","lune07.png","lune08.png","lune09.png","lune10.png","lune11.png","lune12.png","lune13.png","lune14.png","lune15.png","lune16.png","lune17.png","lune18.png","lune19.png","lune20.png","lune21.png","lune22.png","lune23.png","lune24.png","lune25.png","lune26.png","lune27.png","lune28.png","lune29.png","lune30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 9,
              hour_startY: 177,
              hour_array: ["Heures0.png","Heures1.png","Heures2.png","Heures3.png","Heures4.png","Heures5.png","Heures6.png","Heures7.png","Heures8.png","Heures9.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 245,
              minute_startY: 177,
              minute_array: ["Heures0.png","Heures1.png","Heures2.png","Heures3.png","Heures4.png","Heures5.png","Heures6.png","Heures7.png","Heures8.png","Heures9.png"],
              minute_zero: 0,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 130,
              second_startY: 407,
              second_array: ["S0.png","S1.png","S2.png","S3.png","S4.png","S5.png","S6.png","S7.png","S8.png","S9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 270,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'FondAOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 200,
              y: 9,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 151,
              y: 39,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 9,
              hour_startY: 177,
              hour_array: ["Heures0.png","Heures1.png","Heures2.png","Heures3.png","Heures4.png","Heures5.png","Heures6.png","Heures7.png","Heures8.png","Heures9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 245,
              minute_startY: 177,
              minute_array: ["Heures0.png","Heures1.png","Heures2.png","Heures3.png","Heures4.png","Heures5.png","Heures6.png","Heures7.png","Heures8.png","Heures9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: BT Déconnecté,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: BT Connecté,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT Déconnecté"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "BT Connecté"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 167,
              w: 454,
              h: 121,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 15,
              y: 289,
              w: 136,
              h: 95,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 0,
              w: 390,
              h: 69,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 156,
              y: 71,
              w: 341,
              h: 94,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 15,
              y: 71,
              w: 135,
              h: 95,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 246,
              y: 304,
              w: 65,
              h: 65,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 304,
              w: 65,
              h: 65,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}